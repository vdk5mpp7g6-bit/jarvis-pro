# JARVIS PRO – iPhone Web-App + Siri-KI

## Wichtig zu wissen
Diese Web-App kann ohne Mac verwendet werden, sobald sie über eine HTTPS-Adresse veröffentlicht ist. Sie enthält ein futuristisches HUD, Texteingabe, optionale Browser-Spracherkennung, deutsche Sprachausgabe, lokale Aufgaben und einen einfachen Timer. Sie ist noch keine native App und kann iOS nicht uneingeschränkt steuern.

**Die KI-Antworten laufen über den iPhone-Kurzbefehl „JARVIS KI“**, nicht über einen in der Website eingebauten API-Schlüssel. Damit bleibt der OpenAI-API-Schlüssel aus dem Webcode heraus. Falls die Aktion „ChatGPT fragen“ in deiner Kurzbefehle-App nicht verfügbar ist, kann alternativ die ChatGPT-App manuell geöffnet werden; der Web-Knopf kann dann je nach iOS-Konfiguration nicht automatisch eine Antwort zurückbekommen.

## 1. Dateien veröffentlichen – nur iPhone nötig
Die Dateien müssen unter einer HTTPS-Adresse erreichbar sein, damit Safari sie als Web-App installieren kann. Du kannst mit einem Web-Hostingdienst arbeiten, der statische HTML-Dateien veröffentlicht. Lade diese Dateien gemeinsam hoch:
- `index.html`
- `manifest.webmanifest`
- `jarvis-icon.svg`
- `sw.js`

Ich habe sie nicht für dich online gestellt; dieses ZIP ist der Quellcode, keine bereits gehostete Website. Gib API-Schlüssel niemals in HTML-Dateien ein.

## 2. Zum Home-Bildschirm hinzufügen
1. Öffne die veröffentlichte HTTPS-Adresse in Safari.
2. Tippe auf „Teilen“.
3. Wähle „Zum Home-Bildschirm“ bzw. „Zum Home-Bildschirm hinzufügen“.
4. Wenn angeboten, aktiviere „Als Web-App öffnen“ und tippe auf „Hinzufügen“.

## 3. Siri-Kurzbefehl „JARVIS KI“ erstellen
Die genauen Aktionsnamen können je nach iOS-Version und installierter ChatGPT-App leicht abweichen.

1. Öffne Apples App **Kurzbefehle** und tippe auf `+`.
2. Nenne den Kurzbefehl genau `JARVIS KI`.
3. Füge die Aktion **Eingabe abfragen** oder **Diktieren** hinzu, falls du direkt per Stimme fragen möchtest. Für eine Übergabe aus der Web-App verwende möglichst die übergebene Kurzbefehl-Eingabe als Text.
4. Füge die Aktion **ChatGPT fragen** hinzu (falls sie auf deinem Gerät angeboten wird) und übergib den diktierten Text bzw. die Kurzbefehl-Eingabe.
5. Füge **Text sprechen** hinzu und lass die Antwort der ChatGPT-Aktion sprechen.
6. Teste den Kurzbefehl zunächst direkt in Kurzbefehle. Danach kannst du sagen: „Hey Siri, JARVIS KI“.
7. Falls die ChatGPT-Aktion nicht verfügbar ist, kannst du den Kurzbefehl mit „Diktieren“, „Text“ und „Text sprechen“ als einfache Sprachroutine einrichten; das ist dann allerdings keine KI-Antwort.

Der Button „JARVIS KI via Siri“ versucht den Kurzbefehl mit dem Namen `JARVIS KI` zu öffnen und den eingegebenen Text zu übergeben. Das URL-Verhalten hängt von iOS und Kurzbefehle-Einstellungen ab. Falls die Übergabe nicht funktioniert, starte den Kurzbefehl direkt mit Siri und diktiere deine Frage.

## 4. Lokale Funktionen
- `Timer 5` startet einen fünfminütigen Timer, während die Web-App geöffnet bleibt. Browser-Timer sind nicht zuverlässig, wenn iOS die Web-App pausiert oder beendet.
- `Aufgabe Mathe lernen` oder `Erinnere mich an Mathe lernen` speichert eine Aufgabe im lokalen Browserspeicher dieser Web-App. Das erstellt **keine** Apple-Erinnerung.
- Die Browser-Spracherkennung ist nicht in jeder iOS/Safari-Version verfügbar. Wenn sie nicht funktioniert, nutze das Mikrofon-Diktat der iPhone-Tastatur oder den Siri-Kurzbefehl.
- Die Sprachausgabe erfolgt über die eingebaute deutsche Stimme, sofern verfügbar.

## 5. Datenschutz
- Die lokalen Aufgaben werden im Browser auf diesem Gerät gespeichert.
- Das Mikrofon wird erst nach Antippen angefordert.
- Keine API-Schlüssel in die Website eintragen.
- Teile keine sensiblen Informationen mit einem KI-Dienst, wenn du nicht möchtest, dass sie verarbeitet werden.

## Apple-Anleitung
- Web-App auf den Home-Bildschirm: https://support.apple.com/guide/iphone/open-as-web-app-iphea86e5236/27/ios
- Kurzbefehle: https://support.apple.com/guide/iphone/shortcuts-iph47e1c9d7d/27/ios
